﻿using System;
using System.Linq;

namespace Kosarica
{
    class Kosarica<T>
    {
        private T in_cart;

        public T In_cart
        {
            get => in_cart;

            set => in_cart = value;
        }
        public Kosarica(T in_cart)
        {
            this.In_cart = in_cart;
        }
        public override string ToString()
        {
            if (in_cart is Array array)
                return $"Košarica vsebuje: [{string.Join(", ", array.Cast<object>())}]";
            return $"Košarica vsebuje: {in_cart}";
        }
    }


    class Oseba
    {
        private string name;
        private string surname;
        private int age;

        public string Name
        {
            get => name;

            set => name = value;
        }

        public string Surname
        {
            get => surname;

            set => surname = value;
        }

        public int Age
        {
            get => age;

            set => age = value;
        }

        public Oseba(string name, string surname, int age)
        {
            this.Name = name;
            this.Surname = surname;
            this.Age = age;
        }

        // Za razliko sem dodal ce odkomentiramo se vidi razliko
        
        public override string ToString()
        {
            return $"{Name} {Surname}, {Age} let";
        }
        
    }

    class Program
    {
        static void Main(string[] args)
        {
            // 1. Kosarica with a string
            Kosarica<string> kosaricaNiz = new Kosarica<string>("neki");


            Kosarica<int> kosaricaInt = new Kosarica<int>(213);

   
            Oseba oseba = new Oseba("Juri", "Kuri", 24);
            Kosarica<Oseba> kosaricaPer = new Kosarica<Oseba>(oseba);


            Kosarica<double> kosaricaDec = new Kosarica<double>(3.14159);


            int[] stevila = { 10, 20, 30, 40, 50 };
            Kosarica<int[]> kosaricaTab = new Kosarica<int[]>(stevila);

            string[] nizi = { "Juri", "Kuri", "Iz", "Goriskih", "Brd" };
            Kosarica<string[]> kosaricaTabStr = new Kosarica<string[]>(nizi);


            Console.WriteLine(kosaricaNiz);
            Console.WriteLine(kosaricaInt);
            Console.WriteLine(kosaricaPer);
            Console.WriteLine(kosaricaDec);
            Console.WriteLine(kosaricaTab);
            Console.WriteLine(kosaricaTabStr);


        }
    }
}
