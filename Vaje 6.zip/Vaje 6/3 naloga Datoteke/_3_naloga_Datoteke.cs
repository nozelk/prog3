﻿using System;
using System.IO;

namespace _3_naloga_Datoteke
{
    class _3_naloga_Datoteke
    {

        /// <summary>
        /// Rekurzivno prešteje vse datoteke v podanem imeniku in vseh njegovih podimenikih.
        /// </summary>
        /// <param name="directoryPath">Pot do imenika, v katerem želimo prešteti datoteke.</param>
        /// <returns>Število vseh datotek v podanem imeniku in vseh njegovih podimenikih.</returns>
        static int countFilesRecursive(string directoryPath)
        {
            int count = 0;

            // Preštej datoteke v trenutnem imeniku
            count += Directory.GetFiles(directoryPath).Length;
            // Rekurzivno obdelaj vsak podimenik
            foreach (string subDir in Directory.GetDirectories(directoryPath))
            {
                count += countFilesRecursive(subDir);
            }
            
            return count;
        }

        /// <summary>
        /// Prešteje vse datoteke v podanem imeniku in vseh njegovih podimenikih z uporabo vgrajene funkcije.
        /// </summary>
        /// <param name="directoryPath">Pot do imenika, v katerem želimo prešteti datoteke.</param>
        /// <returns>Število vseh datotek v podanem imeniku in vseh njegovih podimenikih.</returns>
        static int CountFilesWithBuiltInMethod(string directoryPath)
        {
            // Pridobi vse datoteke v vseh direktorijih
            string[] allFiles = Directory.GetFiles(directoryPath, "*", SearchOption.AllDirectories);
            return allFiles.Length;
        }

        static void Main(string[] args)
        {
            string testniFolderPath = Path.Combine(Directory.GetCurrentDirectory(), "TestniFolder");

            // Preveri, če TestniFolder obstaja
            if (!Directory.Exists(testniFolderPath))
            {
                Console.WriteLine("TestniFolder ne obstaja v istem direktoriju kot program!");
                return;
            }

            // Rekurzivna metoda
            int recursiveCount = countFilesRecursive(testniFolderPath);
            Console.WriteLine($"Rekurzivna metoda - Število datotek: {recursiveCount}");

            // Vgrajena metoda
            int builtInCount = CountFilesWithBuiltInMethod(testniFolderPath);
            Console.WriteLine($"Vgrajena metoda - Število datotek: {builtInCount}");

        }
    }
}