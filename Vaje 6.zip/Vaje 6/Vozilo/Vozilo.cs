﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Vozilo
{
    class Vozilo 
    {
        private double gorivo;
        private double kapaciteta;
        private double poraba;

        public double Gorivo
        {
            get => gorivo;

            set
            {
                if (value <= 0)
                    throw new Exception("Vec kot 0");

                if (value > Kapaciteta)
                    throw new Exception("Nemoremo biti vec kot kapaciteta");

                gorivo = value;
            }
        }
        public double Kapaciteta
        {
            get => kapaciteta;

            set
            {
                if (value <= 0)
                    throw new Exception("Vec kot 0");

                kapaciteta = value;
            }
        }
        public double Poraba
        {
            get => poraba;

            set
            {
                if (value <= 0)
                    throw new Exception("Vec kot 0");

                poraba = value;
            }
        }

        public Vozilo(double kapaciteta, double poraba)
        {

            this.Kapaciteta = kapaciteta;
            this.Poraba = poraba;
            this.Gorivo = kapaciteta;
        }

        public double PreostaliKilometri()
        {
            return (this.gorivo / this.poraba) * 100;
        }

        public string Crpalka()
        {
            Gorivo = Kapaciteta;
            return "polno";
        }

        public bool metoda(double[] t)
        {
            double sGas = this.Gorivo;
            
            try
            {
                for (int i = 0; i < t.Length; i++) 
                {

                    if (t[i] < 0)
                        throw new Exception("Manj kot 0...");

                    if (t[i] == 0)
                    {
                        if (i > 0 && t[i - 1] == 0)
                            throw new Exception("2 zap 0");

                        this.Crpalka();
                        continue;
                    }

                    if (t[i] > this.PreostaliKilometri())
                    {
                        return false;
                    }


                    this.Gorivo -= (t[i] / 100) * this.Poraba;
                }
                return true;
            }
            catch
            {
                this.Gorivo = sGas;
                throw;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int uspešniTesti = 0;
            int neuspešniTesti = 0;

            Console.WriteLine("Začenjam testiranje razreda Vozilo...\n");

            // Test 1: Ustvarjanje vozila z veljavnimi parametri
            Test("Ustvarjanje vozila z veljavnimi parametri", () => {
                var vozilo = new Vozilo(50, 5);
                if (vozilo.Gorivo != 50 || vozilo.Kapaciteta != 50 || vozilo.Poraba != 5)
                    throw new Exception("Napačne začetne vrednosti");
                uspešniTesti++;
            });

            // Test 2: Poskus ustvarjanja vozila z negativno kapaciteto
            Test("Poskus ustvarjanja vozila z negativno kapaciteto", () => {
                try
                {
                    var vozilo = new Vozilo(-10, 5);
                    throw new Exception("Ni sprožila izjeme za negativno kapaciteto");
                }
                catch (Exception)
                {
                    uspešniTesti++;
                }
            });

            // Test 3: Poskus ustvarjanja vozila z ničelno porabo
            Test("Poskus ustvarjanja vozila z ničelno porabo", () => {
                try
                {
                    var vozilo = new Vozilo(50, 0);
                    throw new Exception("Ni sprožila izjeme za ničelno porabo");
                }
                catch (Exception)
                {
                    uspešniTesti++;
                }
            });

            // Test 4: Preverjanje PreostaliKilometri
            Test("Preverjanje PreostaliKilometri", () => {
                var vozilo = new Vozilo(50, 5);
                if (vozilo.PreostaliKilometri() != 1000)
                    throw new Exception("Napačen izračun preostalih kilometrov");
                uspešniTesti++;
            });

            // Test 5: Polnjenje goriva
            Test("Polnjenje goriva", () => {
                var vozilo = new Vozilo(50, 5);
                vozilo.Gorivo = 10;
                if (vozilo.Crpalka() != "polno" || vozilo.Gorivo != 50)
                    throw new Exception("Napaka pri polnjenju goriva");
                uspešniTesti++;
            });

            // Test 6: Preverjanje poti brez polnjenja
            Test("Preverjanje poti brez polnjenja", () => {
                var vozilo = new Vozilo(50, 5);
                if (!vozilo.metoda(new double[] { 200, 300 }))
                    throw new Exception("Napaka pri preverjanju veljavne poti");
                if (vozilo.metoda(new double[] { 2000 }))
                    throw new Exception("Napaka - pot bi morala biti neveljavna");
                uspešniTesti++;
            });

            // Test 7: Preverjanje poti s polnjenjem
            Test("Preverjanje poti s polnjenjem", () => {
                var vozilo = new Vozilo(50, 5);
                if (!vozilo.metoda(new double[] { 800, 0, 200 }))
                    throw new Exception("Napaka pri preverjanju poti s polnjenjem");
                uspešniTesti++;
            });

            // Test 8: Dve zaporedni ničli
            Test("Dve zaporedni ničli", () => {
                var vozilo = new Vozilo(50, 5);
                try
                {
                    vozilo.metoda(new double[] { 100, 0, 0, 200 });
                    throw new Exception("Ni sprožila izjeme za dve zaporedni ničli");
                }
                catch (Exception)
                {
                    uspešniTesti++;
                }
            });

            // Test 9: Negativna pot
            Test("Negativna pot", () => {
                var vozilo = new Vozilo(50, 5);
                try
                {
                    vozilo.metoda(new double[] { 100, -50, 200 });
                    throw new Exception("Ni sprožila izjeme za negativno pot");
                }
                catch (Exception)
                {
                    uspešniTesti++;
                }
            });

            // Test 10: Ohranjanje stanja ob napaki
            Test("Ohranjanje stanja ob napaki", () => {
                var vozilo = new Vozilo(50, 5);
                double začetnoGorivo = vozilo.Gorivo;
                try
                {
                    vozilo.metoda(new double[] { 100, 0, 0, 200 });
                }
                catch
                {
                    if (vozilo.Gorivo != začetnoGorivo)
                        throw new Exception("Ni ohranilo začetnega stanja ob napaki");
                }
                uspešniTesti++;
            });

            Console.WriteLine($"\nRezultati testov:\nUspešni: {uspešniTesti}\nNeuspešni: {neuspešniTesti}");
            Console.WriteLine($"Uspešnost: {uspešniTesti * 100.0 / (uspešniTesti + neuspešniTesti):F2}%");
        }

        static void Test(string opis, Action test)
        {
            Console.Write($"Test: {opis}... ");
            try
            {
                test();
                Console.WriteLine("OK");
            }
            catch (Exception e)
            {
                Console.WriteLine($"NEUSPEŠNO: {e.Message}");
            }
        }
    }
    
}
