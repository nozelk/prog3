﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Registracija
{
    class Registracija
    {
        private string firstPart;
        private string secondPart;
        private static List<string> validRegions = new List<string> { "LJ", "KR", "KK", "MB", "MS", "KP", "GO", "CE", "SG", "NM", "PO" };

        public string FirstPart
        {
            get => firstPart;
            set
            {
                if (value.Length != 2)
                    throw new ArgumentException("Prvi del mora imeti 2 znaka.");

                if (!validRegions.Contains(value))
                    throw new ArgumentException($"Območje '{value}' ni veljavno.");

                firstPart = value;
            }
        }

        public string SecondPart
        {
            get => secondPart;
            set
            {
                if (value.Length != 5)
                    throw new ArgumentException("Drugi del mora imeti 5 znakov.");

                if (!value.All(c => char.IsLetterOrDigit(c)))
                    throw new ArgumentException("Drugi del lahko vsebuje le črke in številke.");

                secondPart = value;
            }
        }

        public Registracija(string firstPart, string secondPart)
        {
            FirstPart = firstPart;
            SecondPart = secondPart;
        }

        public static List<string> GetValidRegions() => new List<string>(validRegions);

        public static void AddValidRegion(string region)
        {
            if (region.Length != 2)
                throw new ArgumentException("Koda območja mora biti dolga 2 znaka.");

            if (!validRegions.Contains(region))
                validRegions.Add(region);
        }

        public static bool RemoveValidRegion(string region) => validRegions.Remove(region);

        public override string ToString() => $"{firstPart}{secondPart.Substring(0, 2)}-{secondPart.Substring(2)}";
    }

    class Program
    {
        /// <summary>
        /// Ustvari polje naključnih registracijskih številk.
        /// </summary>
        /// <param name="stRegistracij">Število registracijskih številk, ki jih želimo ustvariti.</param>
        /// <returns>Polje objektov tipa Registracija z naključno generiranimi vrednostmi.</returns>
        static Registracija[] UstvariNakljucneRegistracije(int stRegistracij)
        {
            var registracije = new Registracija[stRegistracij];
            Random rnd = new Random();
            var veljavnaObmocja = Registracija.GetValidRegions();
            const string alfanumericni = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

            for (int i = 0; i < stRegistracij; i++)
            {
                string obmocje = veljavnaObmocja[rnd.Next(veljavnaObmocja.Count)];

                /*
                  char[] znaki = new char[5];
                    for (int i = 0; i < 5; i++)
                    {
                        znaki[i] = alfanumericni[rnd.Next(alfanumericni.Length)];
                    }
                    string registracija = new string(znaki);
                */
                string registracija = new string(Enumerable.Range(0, 5)
                    .Select(_ => alfanumericni[rnd.Next(alfanumericni.Length)])
                    .ToArray());

                registracije[i] = new Registracija(obmocje, registracija);
            }

            return registracije;
        }


        /// <summary>
        /// Izpiše seznam registracijskih številk v konzolo.
        /// </summary>
        /// <param name="registracije">Polje objektov tipa Registracija, ki jih želimo izpisati.</param>
        static void IzpisiRegistracije(Registracija[] registracije)
        {
            foreach (var reg in registracije)
                Console.WriteLine(reg);
            Console.WriteLine($"Skupaj: {registracije.Length} registracij");
        }

        /// <summary>
        /// Izpiše registracijske številke iz določenega območja.
        /// </summary>
        /// <param name="registracije">Polje objektov tipa Registracija, ki jih želimo filtrirati in izpisati.</param>
        /// <param name="obmocje">Koda območja po katerem filtriramo registracije (npr. "LJ", "MB").</param>
        static void IzpisiRegistracijeIzObmocja(Registracija[] registracije, string obmocje)
        {
            /* SQL
            var filtrirane = (
                from r in registracije
                where r.FirstPart == obmocje
                select r
                ).ToArray();
            */
            var filtrirane = registracije.Where(r => r.FirstPart == obmocje).ToArray();
            IzpisiRegistracije(filtrirane);
        }


        /// <summary>
        /// Prešteje registracije po območjih in vrne slovar s frekvenco pojavljanja.
        /// </summary>
        /// <param name="registracije">Polje objektov tipa Registracija za analizo.</param>
        /// <returns>
        /// Slovar, kjer je ključ koda območja (npr. "LJ"), vrednost pa število registracij iz tega območja.
        /// </returns>
        static Dictionary<string, int> PrestejObmocja(Registracija[] registracije)
        {

            /* SQL
              return (
                 from r in registracije
                 group r by r.FirstPart into g
                    select new { Key = g.Key, Count = g.Count() }
                ).ToDictionary(x => x.Key, x => x.Count);

            Klasicno

            var pogostost = new Dictionary<string, int>();
            foreach (var r in registracije)
            {
                if (pogostost.ContainsKey(r.FirstPart))
                    pogostost[r.FirstPart]++;
                else
                    pogostost[r.FirstPart] = 1;
            }
            return pogostost;
            */
            return registracije
                .GroupBy(r => r.FirstPart)
                .ToDictionary(g => g.Key, g => g.Count());
        }


        static void Main(string[] args)
        {
            Registracija[] registracije = UstvariNakljucneRegistracije(100);

            Console.WriteLine("Vse registrske številke:");
            IzpisiRegistracije(registracije);

            string iskamoObmocje = "LJ";
            Console.WriteLine($"\nRegistracije iz območja {iskamoObmocje}:");
            IzpisiRegistracijeIzObmocja(registracije, iskamoObmocje);
             

            var pogostostObmocij = PrestejObmocja(registracije);

            /* z SQL
             var najpogostejseObmocje = (
                from entry in pogostostObmocij
                orderby entry.Value descending
                select entry.Key
                ).First();

            var najredkejseObmocje = (
                from entry in pogostostObmocij
                orderby entry.Value ascending
                select entry.Key
            ).First();
            */
            var najpogostejseObmocje = pogostostObmocij
                                      .OrderByDescending(kv => kv.Value)
                                      .First().Key;
            var najredkejseObmocje = pogostostObmocij
                                    .OrderBy(kv => kv.Value)
                                    .First().Key;

            Console.WriteLine($"\nNajpogostejše območje: {najpogostejseObmocje} ({pogostostObmocij[najpogostejseObmocje]} registracij)");
            Console.WriteLine($"Najredkejše območje: {najredkejseObmocje} ({pogostostObmocij[najredkejseObmocje]} registracij)");

            Registracija.RemoveValidRegion(najpogostejseObmocje);
            Registracija.RemoveValidRegion(najredkejseObmocje);

            Console.WriteLine("\nPreostala veljavna območja:");
            foreach (var obmocje in Registracija.GetValidRegions())
                Console.WriteLine(obmocje);

            /* Lambda nacin
            var filtriraneRegistracije = registracije
                .Where(r => r.FirstPart != najpogostejseObmocje && r.FirstPart != najredkejseObmocje)
                .ToArray();
            */

            var filtriranaTabelaRegistracij = (from r in registracije
                                               where r.FirstPart != najpogostejseObmocje &&
                                                     r.FirstPart != najredkejseObmocje
                                               select r).ToArray();

            Console.WriteLine($"\nPreostale registracije po odstranitvi območij {najpogostejseObmocje} in {najredkejseObmocje}:");
            IzpisiRegistracije(filtriranaTabelaRegistracij);
        }
    }
}