﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LaD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            button1.MouseDown += onClick;
            button1.MouseUp += unClick;
            button2.MouseDown += onClick;
            button2.MouseUp += unClick;
        }

        private void onClick(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            switch (btn.Text)
            {
                case "left":
                    label1.Text = ("<--- clicked");
                    break;

                case "right":
                    label1.Text = ("clicked ---> ");
                    break;

            }
        }

        private void unClick(object sender, MouseEventArgs e)
        {
            label1.Text = ""; 

        }

    }
}
