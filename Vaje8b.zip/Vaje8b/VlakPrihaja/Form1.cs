﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace VlakPrihaja
{
    public partial class Form1 : Form
    {
        private Timer resetTimer;
        private bool isBlinking = false;

        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            resetTimer = new Timer();
            resetTimer.Interval = 500;
            resetTimer.Tick += BlinkTimer_Tick;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!isBlinking)
            {
                resetTimer.Start();
                isBlinking = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            resetTimer.Stop();
            isBlinking = false;

            label1.BackColor = Color.White;
            label2.BackColor = Color.White;
        }

        private void BlinkTimer_Tick(object sender, EventArgs e)
        {
            if (label1.BackColor == Color.Red)
            {
                label1.BackColor = Color.White;
                label2.BackColor = Color.Red;
            }
            else
            {
                label1.BackColor = Color.Red;
                label2.BackColor = Color.White;
            }
        }
    }
}