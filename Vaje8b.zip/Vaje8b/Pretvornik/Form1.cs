﻿using System;
using System.Windows.Forms;

namespace Pretvornik
{
    public partial class Form1 : Form
    {
        private Label activeLabel = null;
        private Timer resetTimer;

        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;

            resetTimer = new Timer();
            resetTimer.Interval = 5000;
            resetTimer.Tick += ResetTimer_Tick;


            this.KeyPress += Form1_KeyPress;
            this.MouseClick += Form1_MouseClick;
        }

        private void Label_Click(object sender, EventArgs e)
        {
            if (activeLabel != null)
            {
                activeLabel.BorderStyle = BorderStyle.FixedSingle;
            }

            activeLabel = (Label)sender;
            activeLabel.BorderStyle = BorderStyle.Fixed3D;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (activeLabel != null && !activeLabel.Bounds.Contains(e.Location))
            {
                activeLabel.BorderStyle = BorderStyle.FixedSingle;
                activeLabel = null;
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (activeLabel != null)
            {
                if (e.KeyChar == (char)Keys.Escape)
                {
                    activeLabel.BorderStyle = BorderStyle.FixedSingle;
                    activeLabel = null;
                }
                else if ((e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '.')
                {
                    activeLabel.Text += e.KeyChar;
                    e.Handled = true;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Globalization.CultureInfo culture = System.Globalization.CultureInfo.InvariantCulture;
            bool conversionSuccessful = false;

            if (!string.IsNullOrEmpty(label1.Text) &&
                double.TryParse(label1.Text, System.Globalization.NumberStyles.Any, culture, out double cm))
            {
                double inches = cm / 2.54;
                double feet = Math.Floor(inches / 12);
                double remainingInches = inches - (feet * 12);

                label2.Text = feet.ToString("0");
                label3.Text = remainingInches.ToString("0.00");
                conversionSuccessful = true;
            }
            else if (!string.IsNullOrEmpty(label2.Text) && !string.IsNullOrEmpty(label3.Text) &&
                     double.TryParse(label2.Text, System.Globalization.NumberStyles.Any, culture, out double feet) &&
                     double.TryParse(label3.Text, System.Globalization.NumberStyles.Any, culture, out double inches))
            {
                double totalInches = (feet * 12) + inches;
                double centimeters = totalInches * 2.54;

                label1.Text = centimeters.ToString("0.00");
                conversionSuccessful = true;
            }

            if (conversionSuccessful)
            {
                resetTimer.Start();
            }
            else
            {
                MessageBox.Show("Vnesite veljavne podatke za pretvorbo");
            }
        }

        private void ResetTimer_Tick(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";

            resetTimer.Stop();
        }
    }
}