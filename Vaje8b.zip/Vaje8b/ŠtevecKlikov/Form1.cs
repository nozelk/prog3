﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ŠtevecKlikov
{
    public partial class Form1 : Form
    {
        private int clickCount = 0;

        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void add(object sender, EventArgs e) 
        {
            clickCount++;
            label2.Text = clickCount.ToString();
        }

    }
}
