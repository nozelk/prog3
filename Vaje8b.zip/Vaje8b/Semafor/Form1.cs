﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semafor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        public void onClick(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            switch (btn.Text)
            {
                case "Rdeca":
                    label1.BackColor = Color.Red;
                    break;

                case "Zelena":
                    label1.BackColor = Color.Green;
                    break;

                case "Rumena":
                    label1.BackColor = Color.Yellow;
                    break;

            }
        }
    }
}
